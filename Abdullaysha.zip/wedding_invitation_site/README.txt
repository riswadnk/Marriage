ABDULLA NK & AYSHA — WEDDING INVITATION

1. Unzip the folder.
2. Open index.html in a browser to preview.
3. To publish, upload the entire wedding_invitation_site folder to a static host
   (for example Netlify, GitHub Pages, or your web host). Keep the assets folder beside index.html.

EDITING:
- Open index.html in a text editor.
- Near the bottom, edit the CONFIG object for names, dateISO (YYYY-MM-DD), time (24-hour),
  venue, locationUrl and musicPath.
- Replace assets/couple-portrait.webp with your own image using the same filename.
- Add a song file as assets/wedding-song.mp3 and set musicPath to
  "assets/wedding-song.mp3", OR visitors can choose a local song using the upload control.

NOTES:
- The supplied illustrated portrait is included and optimized as WebP.
- The current date is set to 9 January 2027 at Nikkah at 5:00 PM.
- Countdown uses the visitor's device timezone. For a globally precise countdown,
  set the desired venue timezone in the JavaScript date construction.
- WhatsApp/social preview metadata is included. Social platforms generally require
  a publicly hosted absolute image URL and may cache previews after first sharing.
- Background audio starts only after a user gesture because mobile browsers block
  autoplay with sound.

ADDED CARTOON GALLERY:
- Three additional illustrated Muslim couple scenes are included in assets/.
- The gallery now displays the original couple portrait plus these three scenes.

BACKGROUND MUSIC:
- The supplied Arabic instrumental track is included at assets/wedding-song.mp3.
- It is configured as the invitation background music. Guests can use the floating music button to play/pause it after opening the invitation.

LATEST UPDATES:
- Venue updated to Neelechu kunnummal house.
- Footer now includes 'With love, Nk family'.
- Scratch-card date is hidden until the scratch interaction reveals it.
